export const DEFAULT_IMAGE_PATH = '/images/avatars/default.png';
